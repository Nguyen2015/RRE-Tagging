#!/bin/bash

git checkout master
git add -A . && git commit -m "$1"
git push origin master

